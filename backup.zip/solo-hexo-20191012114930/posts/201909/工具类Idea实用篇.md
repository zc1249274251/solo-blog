title: 工具类--Idea实用篇
date: '2019-09-26 12:45:40'
updated: '2019-10-12 08:02:09'
tags: [工具]
permalink: /articles/2019/09/26/1569473140719.html
---
![](https://img.hacpai.com/bing/20180607.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

    Idea是写代码是一大利器，但是假如你是从Eclipse上转过来的童鞋，第一次面对Idea，肯定会束手束脚，因为之前的一套快捷键基本都废了，不由得一脸懵逼~~😰 😰 ，下面是我之前踩得一些坑，记录下。。。。。。
      Windows下无脑Next安装，此处不表。。。
###   1. 激活
     https://blog.csdn.net/HALEN001/article/details/81137092       第二种方式  2018年11月10号 22:03亲测可用  
如果 提示Activation code 不是有效的  
1. 1、C:\Windows\System32\drivers\etc目录下找到 hosts 文件   
1. 2、打开hosts文件将 0.0.0.0 account.jetbrains.com 添加到文件末尾   
1. 3、到 http://idea.lanyus.com 网站中 ，点获取注册码，拷贝注册码   
1. 4、将注册码输入Activation code 中   
1. 5、激活完成
      （这块儿是我之前激活方法，现在不知道还能不能用，网上搜搜一大堆）

### 2. 调整Maven路径
      Java程序猿一枚，现在项目大部分都是Maven管理，在这块儿，如果不调整Maven路径，放到自己的本地库，会被Idea默认安装到C盘下边的库里边（这项看自己，我是喜欢把Jar更新到自己的本地库）
   File---Setting-Maven
![217edbd228c240e2a793451ea5c49585.png](https://img.hacpai.com/file/2019/09/217edbd228c240e2a793451ea5c49585-a11d26c3.png)
### 3.修改页面字体大小
    这个看自己，Idea安装好后，字体一般比较小，看的很费事。
![image.png](https://img.hacpai.com/file/2019/09/image-e0cf6589.png)
### 4.修改代码字体大小
![image.png](https://img.hacpai.com/file/2019/09/image-b048d1e4.png)
### 5. 安装常用插件
   1. 阿里巴巴规约
   2.Maven Helper
   3.GsonFormat
   4.DataBase navigator
### 6.调整快捷键方式
  ![image.png](https://img.hacpai.com/file/2019/09/image-ea266537.png)

### 7. 修改自动补全方式
      路径： File----setting---keymap
   搜索“completion”  然后选择Base
### 8.修改setget
     搜索“setter”  然后选择Main menu--Code--Generate  选择你的方式
### 9. 修改生成类注释
    
![image.png](https://img.hacpai.com/file/2019/09/image-19477e3c.png)

新建组，然后添加
*
 * @Param $param$
 * @return $return$
 * @Author zhangxiaofan
 * @Date $Time$ $date$ 
 * @Description   $end$
**/







