title: Docker常用操作
date: '2019-10-26 11:51:30'
updated: '2019-10-26 18:46:03'
tags: [docker]
permalink: /articles/2019/10/26/1572061889977.html
---
![](https://img.hacpai.com/bing/20190716.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

##  cdocker 常用操作

#### 1.linux上安装Docker

#### 2.docker上安装一个简单应用

#### 3.docker上查看在运行应用
   docker ps [-a,]
   
#### 4.docker 查看镜像
  docker images 
  
#### 5.docker 停止容器
   docker  stop 容器Id
   
#### 6.docker 运行容器
       docker run -tid --name nginx -p 80:80 -p 3003:3003 nginx-backup
 
#### 7.docker 容器注册中心备份(两种方式，1.推送Docker中心)
 #####  7.1 docker ps   查看容器Id 
 #####  7.2 docker commit  -p  容器Id   容器备份名称
     e.g. docker commit -p af07d2e20e56     ngnix-backup  
 
 #####  7.3docker images 查看镜像Id
  
  
  ######  7.4 登录DockerHub
       docker login 
      输入用户名和密码
  
  #####   7.5 .给容器镜像打标签 
  docker tag 镜像Id  DockerId/容器备份名称

  #####  7.6.docker push   DockerId/容器备份名称

#####  7.7.等待1两分钟在DockerHub上即可看到推送的备份包

  #### 8.docker容器备份 本地备份
      8.1 还是先把容器备份打成镜像(同上)
	  docker save -o 路径    备份镜像名称
     #docker save -o /data/images-backup/container-tomcat-backup.tar container-tomcat-backup


#### 9.备份的恢复
    1.在docker注册中心
     docker pull docekrId/备份名称:latest

      2.在本地,拷贝到要恢复的机器
      docker load -i 备份名称
####  10.镜像删除
     docker images
    docker rmi -f 镜像Id
  
  
